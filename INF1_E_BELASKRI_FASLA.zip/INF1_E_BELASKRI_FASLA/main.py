#!/usr/bin/python3

import inquirer
import os
import logo
from utils import db
import menu_fonc
import interactions



def main():
    # Nom de la BD à créer
    db_file = "data/dechet_alimentaire.db"

    # Créer une connexion a cette BD
    conn = db.creer_connexion(db_file)

    # Remplir la BD
    db.mise_a_jour_bd(conn, "data/dechet_alimentaire_creation.sql")
    db.mise_a_jour_bd(conn, "data/vues.sql")
    db.mise_a_jour_bd(conn, "data/dechet_alimentaire_inserts_ok.sql")


    while (True) :


        os.system('clear')
        print("\033[38;2;0;128;0m"+logo.logo+"\033[0m")
        print("\t\t"+"_"*len(logo.chaine))
        print("\033[38;2;0;128;0m"+logo.chaine+"\033[0m")
        print("\t\t" + "_" * len(logo.chaine))

        choix = menu_fonc.menu(inquirer.List(
                "choice",
                message="Veuillez entrer votre choix",
                choices=["AFFICHER","REQUETES", "INSERER","SUPPRIMER","METTRE A JOUR","VUES","REINITIALISER BDD","QUITTER"],
            ))
        try :
            if (choix == "AFFICHER") :
                interactions.afficher(conn)
            if (choix == "REQUETES") :
                interactions.requetes(conn)

            if (choix == "INSERER") :
                interactions.inserer(conn)

            if (choix == "SUPPRIMER") :
                interactions.supprimer(conn)

            if (choix == "METTRE A JOUR") :
                interactions.mettre_a_jour(conn)
            if (choix == "VUES") :
                interactions.vues(conn)

            if (choix == "REINITIALISER BDD") :
                interactions.reinitialiser(conn)

            if (choix == "QUITTER"):
                print("Au revoir :) ")
                conn.close()
                return
        except Exception as e:
            menu_fonc.afficher_erreur('ERREUR !')
            menu_fonc.afficher_erreur(e)

        # demande un input au utilisateur pour continuer la boucle
        print("\ntape ENTERER pour continuer...")
        input()



if __name__ == "__main__":
    main()
