import inquirer
import tabulate
import sqlite3

"""_____________________________________________________________________"""
def noms_tables(conn: sqlite3.Connection):
    """
    retourne les noms des tables
    """

    # Se connecter à la base de données
    curseur = conn.cursor()

    # Obtenir la liste des noms de table
    curseur.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = [row[0] for row in curseur.fetchall()]

    return tables
"""_____________________________________________________________________"""
def colonnes(conn: sqlite3.Connection, nom_table: str):
    """
    retourne la liste des noms de colonnes
    """
    # Se connecter à la base de données
    curseur = conn.cursor()

    # Obtenir la liste des noms de colonnes
    curseur.execute(f"PRAGMA table_info({nom_table})")
    colonnes = [row[1] for row in curseur.fetchall()]

    return colonnes

"""_____________________________________________________________________"""
def menu(choices: inquirer.List):
    """
    *Affiche une liste de choix et demande à l'utilisateur d'en choisir un
    *menu_fonc.menu(inquirer.List(
                "choice", # Toujours donner "choice" ici
                message="Voici le message à afficher",
                les_choix=["CHOIX 1", "CHOIX 2", "CHOIX 3"],
            ))
    """

    questions = [choices]
    reponses = inquirer.prompt(questions)
    return reponses['choice']
"""_____________________________________________________________________"""

def selectionner_table(conn):
    """
    *Menu pour choisir la table à afficher
    Demande à l'utilisateur de choisir une table et retourne le nom
    """
    return menu(inquirer.List(
            "choice",
            message="Sélectionnez une table",
            choices=[table for table in noms_tables(conn)],
        ))
"""_____________________________________________________________________"""

def selectionner_colonne(conn: sqlite3.Connection, nom_table: str):
    """
    *Menu pour choisir la colonne à afficher
    Demande à l'utilisateur de choisir une colonne dans la table donnée et retourne le nom
    """

    return menu(inquirer.List(
            "choice",
            message="Choisissez une colonne",
            choices=colonnes(conn, nom_table),
        ))
"""_____________________________________________________________________"""

def selectionner_ligne(conn: sqlite3.Connection, nom_table: str):
    """
    *Menu pour choisir la ligne à afficher
    Demande à l'utilisateur de choisir une ligne dans la table donnée et la retourne
    """
    # Récupérer toutes les lignes
    cur = conn.cursor()
    cur.execute(f"SELECT * FROM {nom_table}")
    lignes = cur.fetchall()

    return menu(inquirer.List(
            "choice",
            message="Choisissez ",
            choices=[[col for col in ligne] for ligne in lignes],
        ))
"""_____________________________________________________________________"""

def demander_confirmation(conn: sqlite3.Connection, message: str):
    """
    Demande à l'utilisateur de confirmer
    Renvoie True si confirmé
    """
    choix = menu(inquirer.List(
            "choice",
            message=message,
            choices=["OUI", "NON"],
        ))

    return choix == "OUI"
"""_____________________________________________________________________"""

def afficher_table(conn: sqlite3.Connection, nom_table: str):
    """
    Affiche tous les éléments de la table demandée

    """
    cur = conn.cursor()

    cur.execute(f"SELECT * FROM {nom_table}")

    lignes = cur.fetchall()

    print(tabulate.tabulate(lignes, colonnes(conn, nom_table), tablefmt='grid'))
"""_____________________________________________________________________"""

def afficher_colonne(conn: sqlite3.Connection, nom_table: str, nom_colonne: str):
    """
    Affiche tous les éléments de la colonne demandée
    """
    cur = conn.cursor()

    cur.execute(f"SELECT {nom_colonne} FROM {nom_table}")

    lignes = cur.fetchall()

    print(tabulate.tabulate(lignes, [nom_colonne], tablefmt='grid'))
"""_____________________________________________________________________"""

def afficher_succes(texte: str):
    """
    Affiche un texte en couleur verte
    """
    print(f"    \033[32m✓ {texte}\033[0m")

"""_____________________________________________________________________"""

def afficher_erreur(texte: str):
    """
    Affiche un texte en couleur rouge
    """
    print(f"    \033[31mX {texte}\033[0m")

