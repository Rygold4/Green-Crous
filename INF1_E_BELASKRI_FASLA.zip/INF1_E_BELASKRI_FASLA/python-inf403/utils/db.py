
import sqlite3
import re
from typing import List

import menu_fonc

def regexp(expr, item) :
    """
    Vérifie si une expression régulière correspond à une chaîne de caractères.
    Retourne True si une correspondance est trouvée, sinon False.
    """
    reg = re.compile(expr)
    return reg.search(item) is not None


def creer_connexion(db_file):
    """Crée une connexion a la base de données SQLite spécifiée par db_file

    :param db_file: Chemin d'accès au fichier SQLite
    :return: Objet connexion ou None
    """

    try:
        conn = sqlite3.connect(db_file)
        # On active les foreign keys
        conn.execute("PRAGMA foreign_keys = 1")
        # ajouter regexp fonction
        conn.create_function('REGEXP', 2, regexp)
        return conn
    except sqlite3.Error as e:
        print(e)

    return None


def mise_a_jour_bd(conn: sqlite3.Connection, file: str):
    """Exécute sur la base de données toutes les commandes contenues dans le
    fichier fourni en argument.

    Les commandes dans le fichier `file` doivent être séparées par un
    point-virgule.

    :param conn: Connexion à la base de données
    :type conn: sqlite3.Connection
    :param file: Chemin d'accès au fichier contenant les requêtes
    :type file: str
    """

    # Lecture du fichier et placement des requêtes dans un tableau
    sqlQueries = []

    with open(file, 'r') as f:
        createSql = f.read()
        sqlQueries = createSql.split(";")

    # Exécution de toutes les requêtes du tableau
    cursor = conn.cursor()
    for query in sqlQueries:
        cursor.execute(query)

    # Validation des modifications
    conn.commit()
"""_____________________________________________________________________"""
def insertion(conn: sqlite3.Connection, nom_table: str, valeurs: List[str]):
    """
    Insère une ligne dans la base de données
    """
    cur = conn.cursor()

    requete = "INSERT INTO " + nom_table + " VALUES ("
    for i in range(len(valeurs)):

        if i < len(valeurs) - 1:
            requete += "'" + valeurs[i] + "', "
        else:
            requete += "'" + valeurs[i] + "')"

    # Exécuter la requête et l'afficher en cas de succès
    cur.execute(requete)
    print()
    conn.commit()
    menu_fonc.afficher_succes(requete)
"""_____________________________________________________________________"""
def suppression_lignes(conn: sqlite3.Connection, nom_table: str, lignes: List[List]):
    """
    Supprime des lignes dans la base de données
    """

    # Retourner si la liste des lignes à supprimer est vide
    if len(lignes) == 0:
        return

    cur = conn.cursor()

    # Obtenir les noms des colonnes de la table
    entetes = menu_fonc.colonnes(conn, nom_table)

    toutes_requetes = ''

    # Faire une requête pour chaque ligne
    for ligne in lignes:

        # Construire la requête
        requete = "DELETE FROM " + nom_table + " WHERE ("
        for i in range(len(ligne)):
            requete += entetes[i] + " = "
            requete += "\'" + str(ligne[i]) + "\'"
            if i < len(entetes) - 1:
                requete += " AND "
        requete += ");"

        # Exécuter la requête et l'afficher en cas de succès
        toutes_requetes += requete + "\n"
        cur.execute(requete)
        menu_fonc.afficher_succes(requete)

    # Appliquer les modifications
    conn.commit()
"""_____________________________________________________________________"""
def mise_a_jour_ligne(conn: sqlite3.Connection, nom_table: str, ligne: List[List], valeur: str):
    """
    METTRE À JOUR une ligne dans la base de données
    """

    cur = conn.cursor()

    # Obtenir les noms des colonnes de la table
    entetes = menu_fonc.colonnes(conn, nom_table)

    # Construire la requête
    requete = "UPDATE " + nom_table
    requete += " SET " + list(valeur.keys())[0] + " = \'" + str(valeur[list(valeur.keys())[0]]) + "\'"
    requete += " WHERE ("
    for i in range(len(ligne)):
        requete += entetes[i] + " = "
        requete += "\"" + str(ligne[i]) + "\""
        if i < len(entetes) - 1:
            requete += " AND "
    requete += ")"

    # Exécuter la requête et l'afficher en cas de succès
    cur.execute(requete)
    print()
    conn.commit()
    menu_fonc.afficher_succes(requete)
