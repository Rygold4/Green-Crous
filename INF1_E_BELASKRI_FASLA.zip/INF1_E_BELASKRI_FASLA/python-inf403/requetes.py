'''def select_tous_les_noms_Campus(conn):
    """
    Affiche la liste de tous les campus.

    :param conn: Connexion à la base de données
    """
    cur = conn.cursor()
    cur.execute("""
                SELECT nom_campus 
                FROM Campus
                """)

    rows = cur.fetchall()

    for row in rows:
        print(row)
def select_tous_les_traitement(conn):
    """
    Affiche la liste de tous les campus.

    :param conn: Connexion à la base de données
    """
    cur = conn.cursor()
    cur.execute("""
                SELECT * 
                FROM Traitements
                """)

    rows = cur.fetchall()

    for row in rows:
        print(row)'''

def afficher_menu_resto(conn,nom_restaurant,jour_menu):
    """
    Affiche la liste de tous les campus.

    :param conn: Connexion à la base de données
    """
    cur = conn.cursor()
    cur.execute("""
                SELECT nom_plat 
                FROM Menus
                WHERE nom_restaurant=? AND jour_menu=?
                """,(nom_restaurant,jour_menu))

    rows = cur.fetchall()

    for row in rows:
        print(row)
def resto_qdmax(conn):
    """
    Affiche la liste de tous les campus.

    :param conn: Connexion à la base de données
    """
    cur = conn.cursor()
    cur.execute("""
                WITH quantitedechtotparplat AS (
                SELECT nom_plat, SUM(quantite_produite) AS quantite_totale_dechet
                FROM Quantites_dechets_plat
                GROUP BY nom_plat
            ),
            rtotdech AS (
                SELECT m.nom_restaurant, SUM(q.quantite_totale_dechet) AS total_dechets
                FROM Menus m
                JOIN quantitedechtotparplat q ON m.nom_plat = q.nom_plat
                GROUP BY m.nom_restaurant
            )
            SELECT nom_restaurant, total_dechets
            FROM rtotdech
            WHERE total_dechets = (SELECT MAX(total_dechets) FROM rtotdech);
                """,)

    rows = cur.fetchall()

    for row in rows:
        print(row)
def dechets_selon_traitement(conn,nom_traitement):
    """
    Affiche la liste de tous les campus.

    :param conn: Connexion à la base de données
    """
    cur = conn.cursor()
    cur.execute("""
                SELECT type_dechet 
                FROM Dechets
                WHERE nom_traitement=?
                """,(nom_traitement,))

    rows = cur.fetchall()

    for row in rows:
        print(row)

def resto_par_campus(conn,nom_campus):
    """
    Affiche la liste de tous les campus.

    :param conn: Connexion à la base de données
    """
    cur = conn.cursor()
    cur.execute("""
                SELECT nom_restaurant 
                FROM Restaurants
                WHERE nom_campus=?
                """,(nom_campus,))

    rows = cur.fetchall()

    for row in rows:
        print(row)
def traitement_par_plat(conn):
    """
    Affiche la liste de tous les campus.

    :param conn: Connexion à la base de données
    """
    cur = conn.cursor()
    cur.execute("""
                SELECT nom_plat, GROUP_CONCAT(nom_traitement)
                FROM Dechets
                JOIN Quantites_dechets_plat USING (type_dechet)
                GROUP BY nom_plat
                """)
    rows = cur.fetchall()

    for row in rows:
        print(row)

def resto_plat_vege(conn):
    """
    Affiche la liste de tous les campus.

    :param conn: Connexion à la base de données
    """
    cur = conn.cursor()
    cur.execute("""
                SELECT DISTINCT nom_restaurant
                FROM Plats
                JOIN Menus USING (nom_plat)
                WHERE vegetarien_plat="OUI"
                """)
    rows = cur.fetchall()

    for row in rows:
        print(row)

# Assuming `conn` is properly initialized before calling `traitement_par_plat`
def resto_plat_vege(conn):
    """
    Affiche la liste de tous les campus.

    :param conn: Connexion à la base de données
    """
    cur = conn.cursor()
    cur.execute("""
                SELECT DISTINCT nom_restaurant
                FROM Plats
                JOIN Menus USING (nom_plat)
                WHERE vegetarien_plat="OUI"
                """)
    rows = cur.fetchall()

    for row in rows:
        print(row)
def qte_tot_dechet_par_plat(conn,nom_plat):
    """
    Affiche la liste de tous les campus.

    :param conn: Connexion à la base de données
    """
    cur = conn.cursor()
    cur.execute("""
                SELECT nom_plat,SUM(quantite_produite) AS quantite_totale_dechet
                FROM Quantites_dechets_plat
                GROUP BY nom_plat
                HAVING nom_plat=?
                """,(nom_plat,))
    rows = cur.fetchall()

    for row in rows:
        print(row)
def nbr_jour_vege_par_campus(conn,nom_campus):
    """
    Affiche la liste de tous les campus.

    :param conn: Connexion à la base de données
    """
    cur = conn.cursor()
    cur.execute("""
                SELECT nom_restaurant, COUNT(DISTINCT nom_plat)
                FROM Restaurants JOIN Menus USING(nom_restaurant) 
                JOIN Plats USING(nom_plat)
                WHERE vegetarien_plat="OUI"
                GROUP BY nom_restaurant
                HAVING nom_campus=? 
                """,(nom_campus,))
    rows = cur.fetchall()

    for row in rows:
        print(row)