import inquirer
import re
import sqlite3
import tabulate

import menu_fonc
from utils import db


def afficher(conn: sqlite3.Connection):
    """
    Affiche une table ou une colonne
    """

    # L'utilisateur sélectionne une table
    nom_table = menu_fonc.selectionner_table(conn)

    # Demander à l'utilisateur s'il veut afficher la table entière ou seulement une colonne
    choix_utilisateur = menu_fonc.menu(inquirer.List(
            "choice",
            message="Voulez-vous afficher la table entière ou seulement une colonne ?",
            choices=["TABLE ENTIERE", "SEULEMENT UNE COLONNE"],
        ))

    if choix_utilisateur == "TABLE ENTIERE":
        menu_fonc.afficher_table(conn, nom_table)

    if choix_utilisateur == "SEULEMENT UNE COLONNE":
        # L'utilisateur sélectionne une colonne
        nom_colonne = menu_fonc.selectionner_colonne(conn, nom_table)
        menu_fonc.afficher_colonne(conn, nom_table, nom_colonne)
"""_____________________________________________________________________"""
def inserer(conn: sqlite3.Connection):
    """
    Demande à l'utilisateur d'insérer une ligne dans la table de son choix
    """

    # L'utilisateur sélectionne une table
    nom_table = menu_fonc.selectionner_table(conn)
    if nom_table=="Traitements":
        menu_fonc.afficher_erreur("IMPOSSIBLE D'INSERER DANS LA TABLE TRAITEMENTS")
    else:

        # Demander à l'utilisateur de remplir tous les champs
        valeurs = inquirer.prompt([
                                      inquirer.Text(colonne, message=f"Remplissez {colonne}" )
                                      for colonne in menu_fonc.colonnes(conn, nom_table)
                                  ])
        db.insertion(conn, nom_table, [valeurs[cle] for cle in valeurs.keys()])
"""_____________________________________________________________________"""
def supprimer(conn: sqlite3.Connection):
    """
    Permet à l'utilisateur de supprimer des lignes d'une table
    """

    # L'utilisateur sélectionne une table
    nom_table = menu_fonc.selectionner_table(conn)

    # Récupérer toutes les lignes
    cur = conn.cursor()
    cur.execute(f"SELECT * FROM {nom_table}")
    lignes = cur.fetchall() #toutes les lignes de la table

    choix_utilisateur = menu_fonc.menu(inquirer.Checkbox(
            "choice",message="Choisissez les lignes à supprimer",choices=[[col for col in ligne] for ligne in lignes],))

    db.suppression_lignes(conn, nom_table, choix_utilisateur)
"""_____________________________________________________________________"""
def mettre_a_jour(conn: sqlite3.Connection):
    """
    Permet à l'utilisateur de mettre à jour une ligne de la table
    """

    # Sélectionner une table, une ligne et une colonne
    nom_table = menu_fonc.selectionner_table(conn)
    ligne = menu_fonc.selectionner_ligne(conn, nom_table)
    nom_colonne = menu_fonc.selectionner_colonne(conn, nom_table)

    # Demander à l'utilisateur de donner la nouvelle valeur du champ
    valeur = inquirer.prompt([
        inquirer.Text(nom_colonne, message=f"Donnez une nouvelle valeur à {nom_colonne}" )
                              ])

    db.mise_a_jour_ligne(conn, nom_table, ligne, valeur)

"""_____________________________________________________________________"""

def reinitialiser(conn):
    """
    Demande une confirmation à l'utilisateur avant de réinitialiser la base de données
    """
    if menu_fonc.demander_confirmation(conn, "Êtes-vous sûr de vouloir réinitialiser la base de données ?"):
        db.mise_a_jour_bd(conn, "data/dechet_alimentaire_creation.sql")
        #db.mise_a_jour_bd(conn, "data/views.sql")
        db.mise_a_jour_bd(conn, "data/dechet_alimentaire_inserts_ok.sql")
"""_____________________________________________________________________"""

def requetes(conn: sqlite3.Connection):
    """

    """

    cur = conn.cursor()


    # Demander à l'utilisateur de choisir le type de requetes qu'il veut visualiser
    choix_utilisateur = menu_fonc.menu(inquirer.List(
            "choice",
            message="Choisissez un type de requêtes",
            choices=[
                "SELECTION-PROJECTION",
                "OPERATEURS ENSEMBLISTES",
                "JOITURE-AGREGATION",
            ],
        ))

    try:
        if (choix_utilisateur == "SELECTION-PROJECTION"):
            # Demander à l'utilisateur de choisir une requete
            choix1 = menu_fonc.menu(inquirer.List(
                "choice",
                message="Choisissez une requete: ",
                choices=["MENU RESTO x JOUR i", "DECHETS QUE TRAITE LE TRAITEMENT x",
                         "LES RESTAURANTS DU CAMPUS x"],
            ))
            if(choix1=="MENU RESTO x JOUR i"):
                restaurant = inquirer.prompt([
                    inquirer.Text('nom_restaurant', message=f"donner le nom du restaurant")
                ])
                jour = inquirer.prompt([
                    inquirer.Text('jour_menu', message=f"donner le jour")
                ])
                requete=f"""
                SELECT DISTINCT nom_plat 
                FROM Menus
                WHERE nom_restaurant="{restaurant['nom_restaurant']}"
                AND jour_menu="{jour['jour_menu']}"
                """

                cur.execute(requete)
                lignes = cur.fetchall()
                print(tabulate.tabulate(lignes, ["nom_plat"], tablefmt='grid'))

            elif(choix1=="DECHETS QUE TRAITE LE TRAITEMENT x"):
                traitement = inquirer.prompt([
                    inquirer.Text('nom_traitement', message=f"donner le nom du traitement")
                    ])

                requete = f"""SELECT type_dechet 
                            FROM Dechets
                            WHERE nom_traitement="{traitement['nom_traitement']}"
                            """

                # Execute request
                cur.execute(requete)
                lignes = cur.fetchall()
                print(tabulate.tabulate(lignes, ["type_dechets"], tablefmt='grid'))

            elif(choix1=="LES RESTAURANTS DU CAMPUS x"):
                campus = inquirer.prompt([
                    inquirer.Text('nom_campus', message=f"donner le nom de votre campus")
                    ])

                requete = f"""  SELECT nom_restaurant 
                                FROM Restaurants
                                WHERE nom_campus="{campus['nom_campus']}"
                """

                # Execute request
                cur.execute(requete)
                lignes = cur.fetchall()
                print(tabulate.tabulate(lignes,["nom_restaurant"], tablefmt='grid'))



        elif (choix_utilisateur == "OPERATEURS ENSEMBLISTES"):
            print('mazel2')

        elif (choix_utilisateur == "JOITURE-AGREGATION"):
            # Demander à l'utilisateur de choisir une requete
            choix1 = menu_fonc.menu(inquirer.List(
                "choice",
                message="Choisissez une requete: ",
                choices=["LES TRAITEMENTS QUE NECCESSITENT LES DECHETS De CHAQUE PLAT",
                         "LES RESTAURANTS QUI PROPOSENT DES PLATS VEGETARIENS",
                         "QUANTITE DECHETS TOTALE PAR PLAT"],

            ))
            if(choix1=="LES TRAITEMENTS QUE NECCESSITENT LES DECHETS De CHAQUE PLAT"):

                requete = """
                            SELECT nom_plat, GROUP_CONCAT(nom_traitement)
                            FROM Dechets
                            JOIN Quantites_dechets_plat USING (type_dechet)
                            GROUP BY nom_plat
                          """
                colonne = ["nom_plat","Liste_des_traitements"]

                # Execute request
                cur.execute(requete)
                lignes = cur.fetchall()
                print(tabulate.tabulate(lignes, colonne, tablefmt='grid'))
            if(choix1=="LES RESTAURANTS QUI PROPOSENT DES PLATS VEGETARIENS"):

                requete = """
                            SELECT DISTINCT nom_restaurant
                            FROM Plats
                            JOIN Menus USING (nom_plat)
                            WHERE vegetarien_plat="OUI"
                          """
                colonne = ["nom_restaurant"]

                # Execute request
                cur.execute(requete)
                lignes = cur.fetchall()
                print(tabulate.tabulate(lignes, colonne, tablefmt='grid'))
            if(choix1=="QUANTITE DECHETS TOTALE PAR PLAT"):

                requete = """
                            SELECT nom_plat,SUM(quantite_produite) AS quantite_totale_dechet
                            FROM Quantites_dechets_plat
                            GROUP BY nom_plat
                          """
                colonne = ["nom_plat","quantite_totale_dechet"]

                # Execute request
                cur.execute(requete)
                lignes = cur.fetchall()
                print(tabulate.tabulate(lignes, colonne, tablefmt='grid'))
    except Exception as e:
        menu_fonc.afficher_erreur('ERREUR CHOIX DE REQUETE!')
        menu_fonc.afficher_erreur(e)

"""_____________________________________________________________________"""
