-- Jeux de donnees NOK (ne doit pas marcher àpres avoir execute le jeux de donnees NOK)


-- Erreur : valeur manquante dans la table mere Restaurants (foreign constraint)
INSERT INTO Menus VALUES ('Riz macedoine au thon','Green', 'lundi');
-- Erreur : Restaurant existant
INSERT INTO Restaurants VALUES ('Arum', '5 All. Antonio Machado, 31100 Toulouse', '300','Universite Toulouse');

-- Erreur : Valeur negative (Ne respect pas la contrainte)
INSERT INTO Quantites_dechets_plat  VALUES ('Poulet sauce basquaise', 'Restes de repas', -0.6);

-- Erreur : unite_duree autre que "heure", "jour", "mois", "annee"
INSERT INTO Traitements Values ('incineration', 300, 60, 'minutes', 150);

-- Erreur : Dechet avec Traitement inconnu
INSERT INTO Dechets VALUES ('Coquilles d oeufs','fruit de mer','recyclage');

-- Erreur : type plat autre que "entree", "plat_principal", "dessert"
INSERT INTO Plats Values ('Creme brulee', 'boisson', 'OUI');
-- Erreur : vegetarien à la place de "OUI" ou "NON"
INSERT INTO Plats Values ('Creme brulee', 'dessert', 'vegetarien');
-- Erreur : Restaurant sans campus existant
INSERT INTO Restaurants Values ('Crous du havre', '25 Rue Philippe Lebon, 76600 Le Havre, France', 130, 'Universite Le Havre Normandie');


-- Erreur : Primary key non respecte
INSERT INTO Campus VALUES ('Universite de Picardie Jules Verne', 'annecy',2);

-- Erreur : NOT NULL field leaved NULL
INSERT INTO Menus VALUES ('Poulet sauce basquaise','le Capu', NULL);