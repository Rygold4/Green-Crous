DROP TABLE IF EXISTS Menus;
DROP TABLE IF EXISTS Restaurants;
DROP TABLE IF EXISTS Quantites_dechets_plat;
DROP TABLE IF EXISTS Dechets;
DROP TABLE IF EXISTS Traitements;
DROP TABLE IF EXISTS Campus;
DROP TABLE IF EXISTS Plats;

-- Pour activer les FKs

PRAGMA FOREIGN_KEYS=ON;


CREATE TABLE Campus (
   nom_campus TEXT NOT NULL PRIMARY KEY,
   ville_campus TEXT NOT NULL ,
   nombre_restaurant_campus INTEGER NOT NULL ,
   CONSTRAINT ch_cmp_nbrc CHECK (nombre_restaurant_campus >=0)
);

CREATE TABLE Restaurants (
   nom_restaurant TEXT NOT NULL PRIMARY KEY,
   adresse_restaurant TEXT NOT NULL,
   capacite_restaurant INTEGER NOT NULL,
   nom_campus TEXT NOT NULL ,
   CONSTRAINT fk_res_nc FOREIGN KEY (nom_campus)REFERENCES Campus(nom_campus),
   CONSTRAINT ch_res_cap CHECK (capacite_restaurant >=0)

);

CREATE TABLE Plats (

   nom_plat TEXT NOT NULL PRIMARY KEY,
   type_plat TEXT NOT NULL,
   vegetarien_plat TEXT NOT NULL ,
   CONSTRAINT ck_pla_tp CHECK (type_plat="entree" OR type_plat="plat_principal" OR type_plat="dessert"),
   CONSTRAINT ck_pla_vp CHECK (vegetarien_plat="NON" OR vegetarien_plat="OUI")

);

CREATE TABLE Traitements (
   nom_traitement TEXT NOT NULL PRIMARY KEY,
   quantite_traitement REAL NOT NULL,
   duree_traitement  INTEGER NOT NULL,
   unite_duree_traitement TEXT NOT NULL,
   empreinte_carbone_traitement REAL NOT NULL,

   CONSTRAINT ck_trai_nom CHECK (nom_traitement="enfouissement" OR nom_traitement="incineration" OR nom_traitement="compostage" OR nom_traitement="methanisation"),
   CONSTRAINT ck_trai_unitDuree CHECK (unite_duree_traitement="heure" OR unite_duree_traitement="jour" OR unite_duree_traitement="mois" OR unite_duree_traitement="annee")


);

CREATE TABLE Dechets (
   type_dechet TEXT NOT NULL PRIMARY KEY,
   provenance_dechet TEXT NOT NULL,
   nom_traitement TEXT NOT NULL,
   CONSTRAINT fk_dch_trm FOREIGN KEY (nom_traitement) REFERENCES Traitements(nom_traitement)
);



CREATE TABLE Menus(
   nom_plat TEXT NOT NULL,
   nom_restaurant TEXT NOT NULL,
   jour_menu TEXT NOT NULL,

   CONSTRAINT pk_menu_pr PRIMARY KEY (nom_plat ,nom_restaurant),

   CONSTRAINT fk_menu_pl FOREIGN KEY (nom_plat) REFERENCES Plats(nom_plat),

   CONSTRAINT fk_menu_ru FOREIGN KEY (nom_restaurant) REFERENCES Restaurants(nom_restaurant),

   CONSTRAINT ck_menu_jr CHECK (jour_menu="dimanche" OR jour_menu="lundi" OR jour_menu="mardi" OR jour_menu="mercredi" OR jour_menu="jeudi" OR jour_menu="vendredi" OR jour_menu="samedi")

   );



CREATE TABLE Quantites_dechets_plat(
   nom_plat TEXT NOT NULL,
   type_dechet TEXT NOT NULL,
   quantite_produite REAL NOT NULL,

   CONSTRAINT pk_qdp_pd PRIMARY KEY (nom_plat ,type_dechet),
   CONSTRAINT fk_qdp_pl FOREIGN KEY (nom_plat) REFERENCES Plats(nom_plat),
   CONSTRAINT fk_qdp_de FOREIGN KEY (type_dechet) REFERENCES Dechets(type_dechet),
   CONSTRAINT ck_qdp_qp CHECK (quantite_produite >=0)

   );