#!/usr/bin/python3

import inquirer
import os
import LOGO
from utils import db
import menu_fonc
import interactions
import requetes


def main():
    # Nom de la BD à créer
    db_file = "data/dechet_alimentaire.db"

    # Créer une connexion a la BD
    conn = db.creer_connexion(db_file)

    # Remplir la BD
    print("1. On crée la bd et on l'initialise avec des premières valeurs.")
    db.mise_a_jour_bd(conn, "data/dechet_alimentaire_creation.sql")
    db.mise_a_jour_bd(conn, "data/dechet_alimentaire_inserts_ok.sql")

    # while (True) :
    #
    #
    #     os.system('clear')
    #
    #     print("\033[38;2;0;128;0m"+LOGO.logo+"\033[0m")
    #     print("\t\t"+"_"*len(LOGO.chaine))
    #     print("\033[38;2;0;128;0m"+LOGO.chaine+"\033[0m")
    #     print("\t\t" + "_" * len(LOGO.chaine))
    #     choix = menu_fonc.menu(inquirer.List(
    #             "choice",
    #             message="Veuillez entrer votre choix",
    #             choices=["AFFICHER","REQUETES", "INSERER","SUPPRIMER","METTRE A JOUR","REINITIALISER BDD","QUITTER"],
    #         ))
    #     try :
    #         if (choix == "AFFICHER") :
    #             interactions.afficher(conn)
    #         if (choix == "REQUETES") :
    #             interactions.requetes(conn)
    #
    #         if (choix == "INSERER") :
    #             interactions.inserer(conn)
    #
    #         if (choix == "SUPPRIMER") :
    #             interactions.supprimer(conn)
    #
    #         if (choix == "METTRE A JOUR") :
    #             interactions.mettre_a_jour(conn)
    #
    #         if (choix == "REINITIALISER BDD") :
    #             interactions.reinitialiser(conn)
    #
    #         if (choix == "QUITTER"):
    #             print("Au revoir :) ")
    #             conn.close()
    #             return
    #     except Exception as e:
    #         menu_fonc.afficher_erreur('ERREUR !')
    #         menu_fonc.afficher_erreur(e)
    #
    #     # Ask a user input before looping
    #     print("\ntape ENTERER pour continuer...")
    #     input()
    #
    #
    #








    # Lire la BD
    #print("2. Liste de tous les campus:")
    #select_tous_les_noms_Campus(conn)
    #print("2. Liste de tous les traitements:")
    #select_tous_les_traitement(conn)
    #afficher_menu_resto(conn,"ecole Centrale","vendredi")
    #dechets_selon_traitement(conn, "compostage")
    #resto_par_campus(conn, "Universite de Grenoble Alpes")
    #traitement_par_plat(conn)
    #resto_plat_vege(conn)
    #qte_tot_dechet_par_plat(conn, 'Carottes rapes')
    requetes.resto_qdmax(conn)
if __name__ == "__main__":
    main()
