objectif
Base de donnés pour gestion de dechéts alimentaire au sein des restautrants universitaire CROUS.

·Pour pouvoir executer notre projet il faut ouvrir le terminal et executer les deux commandes :

          pip install –r requirement.txt
          python main.py

Vous trouverez ainsi le fichier dechet_alimentaire_inserts_nok.sql qui contient des insertions fausses
pour les tester il suffit d’ajouter son contenu au fichier dechet_alimentaire_inserts_ok.sql.

Le menu principal est simple à manipuler : utilisez les touches fléchées haut/bas pour naviguer,
et dans la section "supprimer", appuyez sur la touche espace du clavier pour sélectionner les lignes à supprimer.