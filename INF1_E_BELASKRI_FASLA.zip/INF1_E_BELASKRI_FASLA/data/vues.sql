---donne les campus avec leurs nombre de restaurants
DROP VIEW IF EXISTS Campus_nbr_restaurants;
CREATE VIEW Campus_nbr_restaurants AS
    SELECT c.nom_campus, c.ville_campus, COUNT(r.nom_restaurant) AS nombre_restaurants_campus
    FROM Campus c
    JOIN Restaurants r USING(nom_campus)
    GROUP BY c.nom_campus, c.ville_campus;

---affiche la liste des plats de chaque restau par jour,
---donne de la lisibilité au menu surtt lors d"insertion ou de suppresstion
DROP VIEW IF EXISTS Menus_par_jour;
CREATE VIEW Menus_par_jour AS
    SELECT nom_restaurant, jour_menu, GROUP_CONCAT(nom_plat, ', ') AS plats
    FROM Menus
    GROUP BY nom_restaurant, jour_menu;