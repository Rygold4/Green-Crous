import inquirer
import re
import sqlite3
import tabulate
import menu_fonc
from utils import db


def afficher(conn: sqlite3.Connection):
    """
    Affiche une table ou une colonne
    """

    # L'utilisateur sélectionne une table
    nom_table = menu_fonc.selectionner_table(conn)

    # Demander à l'utilisateur s'il veut afficher la table entière ou seulement une colonne
    choix_utilisateur = menu_fonc.menu(inquirer.List(
            "choice",
            message="Voulez-vous afficher la table entière ou seulement une colonne ?",
            choices=["TABLE ENTIERE", "SEULEMENT UNE COLONNE"],
        ))

    if choix_utilisateur == "TABLE ENTIERE":
        menu_fonc.afficher_table(conn, nom_table)

    if choix_utilisateur == "SEULEMENT UNE COLONNE":
        # L'utilisateur sélectionne une colonne
        nom_colonne = menu_fonc.selectionner_colonne(conn, nom_table)
        menu_fonc.afficher_colonne(conn, nom_table, nom_colonne)
"""_____________________________________________________________________"""
def inserer(conn: sqlite3.Connection):
    """
    Demande à l'utilisateur d'insérer une ligne dans la table de son choix
    """

    # L'utilisateur sélectionne une table
    nom_table = menu_fonc.selectionner_table(conn)
    if nom_table=="Traitements":
        menu_fonc.afficher_erreur("IMPOSSIBLE D'INSERER DANS LA TABLE TRAITEMENTS")
    else:

        # Demander à l'utilisateur de remplir tous les champs
        valeurs = inquirer.prompt([
                                      inquirer.Text(colonne, message=f"Remplissez {colonne}" )
                                      for colonne in menu_fonc.colonnes(conn, nom_table)
                                  ])
        db.insertion(conn, nom_table, [valeurs[cle] for cle in valeurs.keys()])
"""_____________________________________________________________________"""
def supprimer(conn: sqlite3.Connection):
    """
    Permet à l'utilisateur de supprimer des lignes d'une table
    """

    # L'utilisateur sélectionne une table
    nom_table = menu_fonc.selectionner_table(conn)

    # Récupérer toutes les lignes
    cur = conn.cursor()
    cur.execute(f"SELECT * FROM {nom_table}")
    lignes = cur.fetchall() #toutes les lignes de la table

    choix_utilisateur = menu_fonc.menu(inquirer.Checkbox(
            "choice",message="Choisissez les lignes à supprimer",choices=[[col for col in ligne] for ligne in lignes],))

    db.suppression_lignes(conn, nom_table, choix_utilisateur)
"""_____________________________________________________________________"""
def mettre_a_jour(conn: sqlite3.Connection):
    """
    Permet à l'utilisateur de mettre à jour une ligne de la table
    """

    # Sélectionner une table, une ligne et une colonne
    nom_table = menu_fonc.selectionner_table(conn)
    ligne = menu_fonc.selectionner_ligne(conn, nom_table)
    nom_colonne = menu_fonc.selectionner_colonne(conn, nom_table)

    # Demander à l'utilisateur de donner la nouvelle valeur du champ
    valeur = inquirer.prompt([
        inquirer.Text(nom_colonne, message=f"Donnez une nouvelle valeur à {nom_colonne}" )
                              ])

    db.mise_a_jour_ligne(conn, nom_table, ligne, valeur)

"""_____________________________________________________________________"""

def reinitialiser(conn):
    """
    Demande une confirmation à l'utilisateur avant de réinitialiser la base de données
    """
    if menu_fonc.demander_confirmation(conn, "Êtes-vous sûr de vouloir réinitialiser la base de données ?"):
        db.mise_a_jour_bd(conn, "data/dechet_alimentaire_creation.sql")
        db.mise_a_jour_bd(conn, "data/vues.sql")
        db.mise_a_jour_bd(conn, "data/dechet_alimentaire_inserts_ok.sql")
"""_____________________________________________________________________"""

def requetes(conn: sqlite3.Connection):
    """
    chargement des requete selon le choix de l'utilisateur
    """

    cur = conn.cursor()


    # Demander à l'utilisateur de choisir le type de requetes qu'il veut visualiser
    choix_utilisateur = menu_fonc.menu(inquirer.List(
            "choice",
            message="Choisissez un type de requêtes",
            choices=[
                "SELECTION-PROJECTION",
                "OPERATEURS ENSEMBLISTES",
                "JOITURE-AGREGATION",
                "COMPLEXE"
            ],
        ))

    try:
        if (choix_utilisateur == "SELECTION-PROJECTION"):
            # Demander à l'utilisateur de choisir une requete
            choix1 = menu_fonc.menu(inquirer.List(
                "choice",
                message="Choisissez une requete: ",
                choices=["MENU RESTO x JOUR i", "DECHETS QUE TRAITE LE TRAITEMENT x",
                         "LES RESTAURANTS DU CAMPUS x"],
            ))
            if(choix1=="MENU RESTO x JOUR i"):
                nom_table = "Restaurants"
                resto=menu_fonc.selectionner_ligne(conn,nom_table)
                restaurant = resto[0]
                print(restaurant)
                jour = inquirer.prompt([
                    inquirer.Text('jour_menu', message=f"donner le jour")
                ])
                requete=f"""
                SELECT DISTINCT nom_plat 
                FROM Menus
                WHERE nom_restaurant="{restaurant}"
                AND jour_menu="{jour['jour_menu']}"
                """

                cur.execute(requete)
                lignes = cur.fetchall()
                print(tabulate.tabulate(lignes, ["nom_plat"], tablefmt='grid'))

            elif(choix1=="DECHETS QUE TRAITE LE TRAITEMENT x"):
                cur.execute("""SELECT *
                                from Traitements
                            """
                )
                lignes = cur.fetchall()
                #affichage de la liste des traitements
                traitement=menu_fonc.menu(inquirer.List(
                "choice",
                message="Choisissez un traitement: ",
                choices=[ligne[0] for ligne in lignes],))

                requete = f"""SELECT type_dechet 
                            FROM Dechets
                            WHERE nom_traitement="{traitement}"
                            """


                cur.execute(requete)
                lignes = cur.fetchall()
                print(tabulate.tabulate(lignes, ["type_dechets"], tablefmt='grid'))

            elif(choix1=="LES RESTAURANTS DU CAMPUS x"):
                cur.execute("""SELECT *
                                from Campus
                            """
                )
                lignes = cur.fetchall()
                campus = menu_fonc.menu(inquirer.List(
                "choice",
                message="Choisissez votre campus: ",
                choices=[ligne[0] for ligne in lignes],))

                requete = f"""  SELECT nom_restaurant 
                                FROM Restaurants
                                WHERE nom_campus="{campus}"
                """


                cur.execute(requete)
                lignes = cur.fetchall()
                print(tabulate.tabulate(lignes,["nom_restaurant"], tablefmt='grid'))



        elif (choix_utilisateur == "OPERATEURS ENSEMBLISTES"):
            choix1 = menu_fonc.menu(inquirer.List(
                "choice",
                message="Choisissez une requete: ",
                choices=["LES DECHETS QUE GENERE LE PLAT x ET PAS LE PLAT y",
                         "LES RESTAURANTS D'UNE CAPACITE SUP A x QUI PROPOSENT DES PLATS VEGE"],

            ))
            if(choix1=="LES DECHETS QUE GENERE LE PLAT x ET PAS LE PLAT y"):

                cur.execute("""SELECT *
                                from Plats
                            """
                            )
                lignes = cur.fetchall()
                plat1 = menu_fonc.menu(inquirer.List(
                    "choice",
                    message="Choisissez le nom du premier plat: ",
                    choices=[ligne[0] for ligne in lignes], ))
                plat2 = menu_fonc.menu(inquirer.List(
                    "choice",
                    message="Choisissez le nom du deuxieme plat: ",
                    choices=[ligne[0] for ligne in lignes], ))
                print(plat1,plat2)
                requete=f"""
                    SELECT type_dechet 
                    FROM Quantites_dechets_plat
                    WHERE nom_plat="{plat1}"
                    EXCEPT
                    SELECT type_dechet 
                    FROM Quantites_dechets_plat
                    WHERE nom_plat="{plat2}"
                    """

                cur.execute(requete)
                lignes = cur.fetchall()
                print(tabulate.tabulate(lignes, ["type_dechet"], tablefmt='grid'))
            elif(choix1=="LES RESTAURANTS D'UNE CAPACITE SUP A x QUI PROPOSENT DES PLATS VEGE"):
                cap=input("SAISISSEZ LA CAPACITE DU RESTAURANT: ")
                requete = f"""
                            SELECT nom_restaurant 
                            FROM Menus
                            WHERE nom_plat IN (SELECT nom_plat
                                                FROM Plats
                                                WHERE vegetarien_plat == "OUI")
                            INTERSECT
                            SELECT nom_restaurant 
                            FROM Restaurants
                            WHERE capacite_restaurant >={cap}
                           """
                cur.execute(requete)
                lignes = cur.fetchall()
                print(tabulate.tabulate(lignes, ["nom_restaurant"], tablefmt='grid'))




        elif (choix_utilisateur == "JOITURE-AGREGATION"):
            # Demander à l'utilisateur de choisir une requete
            choix1 = menu_fonc.menu(inquirer.List(
                "choice",
                message="Choisissez une requete: ",
                choices=["LES TRAITEMENTS QUE NECCESSITENT LES DECHETS De CHAQUE PLAT",
                         "LES RESTAURANTS QUI PROPOSENT DES PLATS VEGETARIENS",
                         "QUANTITE DECHETS TOTALE PAR PLAT","TRAITEMENT AVEC EMPREINTE CARBONNE MAXIMALE"],

            ))
            if(choix1=="LES TRAITEMENTS QUE NECCESSITENT LES DECHETS De CHAQUE PLAT"):

                requete = """
                            SELECT nom_plat, GROUP_CONCAT(nom_traitement)
                            FROM Dechets
                            JOIN Quantites_dechets_plat USING (type_dechet)
                            GROUP BY nom_plat
                          """

                cur.execute(requete)
                lignes = cur.fetchall()
                print(tabulate.tabulate(lignes, ["nom_plat","Liste_des_traitements"], tablefmt='grid'))
            if(choix1=="LES RESTAURANTS QUI PROPOSENT DES PLATS VEGETARIENS"):

                requete = """
                            SELECT DISTINCT nom_restaurant
                            FROM Plats
                            JOIN Menus USING (nom_plat)
                            WHERE vegetarien_plat="OUI"
                          """
                colonne = ["nom_restaurant"]

                # Execute request
                cur.execute(requete)
                lignes = cur.fetchall()
                print(tabulate.tabulate(lignes, colonne, tablefmt='grid'))
            if(choix1=="QUANTITE DECHETS TOTALE PAR PLAT"):

                requete = """
                            SELECT nom_plat,SUM(quantite_produite) AS quantite_totale_dechet
                            FROM Quantites_dechets_plat
                            GROUP BY nom_plat
                          """

                cur.execute(requete)
                lignes = cur.fetchall()
                print(tabulate.tabulate(lignes, ["nom_plat","quantite_totale_dechet"], tablefmt='grid'))

            if(choix1=="TRAITEMENT AVEC EMPREINTE CARBONNE MAXIMALE"):

                requete = """
                            SELECT nom_traitement,empreinte_carbone_traitement AS EMP_carbonne_max
                            FROM Traitements
                            WHERE empreinte_carbone_traitement=
                                                        ( SELECT MAX(empreinte_carbone_traitement)
                                                          FROM Traitements
                                                        )
                            """
                colonne = ["nom_traitement","EMP_carbonne_max"]

                cur.execute(requete)
                lignes = cur.fetchall()
                print(tabulate.tabulate(lignes, colonne, tablefmt='grid'))
        elif(choix_utilisateur=="COMPLEXE"):
            choix1 = menu_fonc.menu(inquirer.List(
                "choice",
                message="Choisissez une requete: ",
                choices=["LE-"
                         "LES RESTAURANT(S) QUI PRODUIT LA PLUS GRANDE QUANTITE DECHETS"],

            ))
            if(choix1=="LE-LES RESTAURANT(S) QUI PRODUIT LA PLUS GRANDE QUANTITE DECHETS"):
                requete ="""
                WITH quantite_dech_tot_par_plat AS (
                SELECT nom_plat, SUM(quantite_produite) AS quantite_totale_dechet
                FROM Quantites_dechets_plat
                GROUP BY nom_plat
                ),
                total_dechet_resto AS (
                    SELECT m.nom_restaurant, SUM(q.quantite_totale_dechet) AS total_dechets
                    FROM Menus m
                    JOIN quantite_dech_tot_par_plat q ON m.nom_plat = q.nom_plat
                    GROUP BY m.nom_restaurant
                )
                SELECT nom_restaurant, total_dechets
                FROM total_dechet_resto
                WHERE total_dechets = (
                                        SELECT MAX(total_dechets) 
                                        FROM total_dechet_resto
                                      )
                                      
                """
                cur.execute(requete)
                lignes = cur.fetchall()
                print(tabulate.tabulate(lignes, ["nom_restaurant","quantite_totale_dechets"], tablefmt='grid'))
    except Exception as e:
        menu_fonc.afficher_erreur('ERREUR CHOIX DE REQUETE!')
        menu_fonc.afficher_erreur(e)

"""_____________________________________________________________________"""


def vues(conn: sqlite3.Connection):
    """
    Permet à l'utilisateur d'afficher le résultat d'une requête existante (créée dans data/views.sql)
    """

    cur = conn.cursor()
    colonnes = []
    lignes = []

    choix_utilisateur = menu_fonc.menu(inquirer.List(
        "choice",
        message="Choisissez une vue ",
        choices=[
            "CAMPUS AVEC NOMBRE TOTAL DE RESTAURANTS",
            "MENUS AVEC LISTE DES PLATS DU JOUR"],
    ))

    if choix_utilisateur == "CAMPUS AVEC NOMBRE TOTAL DE RESTAURANTS":

        requete = "SELECT * FROM Campus_nbr_restaurants"
        colonnes = ["Campus", "ville", "nombre_restaurants"]

        # Exécuter la requête
        cur.execute(requete)
        lignes = cur.fetchall()

    elif choix_utilisateur == "MENUS AVEC LISTE DES PLATS DU JOUR":

        requete = "SELECT * FROM Menus_par_jour"
        colonnes = ["nom_restaurant","jour","plats"]

        # Exécuter la requête
        cur.execute(requete)
        lignes = cur.fetchall()


    # Afficher le résultat
    print(tabulate.tabulate(lignes, colonnes, tablefmt='grid'))
